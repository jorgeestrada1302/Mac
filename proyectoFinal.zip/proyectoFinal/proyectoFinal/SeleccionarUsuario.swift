//
//  SeleccionarUsuario.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 27/11/24.
//

import Cocoa

class SeleccionarUsuario: NSViewController {
    
    var nivel:String?
    var name:String?
    var puntos: Int!
    var juegosJugados: Int!
    var flag:Bool = false
    var index: Int!
    
    @IBOutlet weak var nicknameTxt: NSTextField!
    @IBOutlet var vcJugador: ViewController!
    @IBOutlet weak var tableView: NSScrollView!
    @objc dynamic var clientLog: [personaOBJ] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func SeleccionarBtn(_ sender: NSButton) {
        if nicknameTxt.stringValue.isEmpty {
            let alert = NSAlert()
            alert.messageText = "¡Error!"
            alert.informativeText = "Por favor, ingresa un nombre para continuar."
            alert.alertStyle = .warning
            alert.runModal()
        } else {
            print("El nickname es: \(nicknameTxt.stringValue)")
        }
    }
    
    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        if (segue.identifier == "seleccionarSegue") {
            let destinoVC = segue.destinationController as! Preguntas
            (segue.destinationController as! Preguntas).clientLog = clientLog
            destinoVC.nivel = nivel
            destinoVC.name = nicknameTxt.stringValue
            destinoVC.puntos = puntos
            destinoVC.juegosJugados = juegosJugados
        } else if (segue.identifier == "crearSegue") {
            let destinoVC = segue.destinationController as! Agregar
        }
    }
}
