//
//  Persona.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 27/11/24.
//

import Cocoa

class Persona: NSObject {

}
