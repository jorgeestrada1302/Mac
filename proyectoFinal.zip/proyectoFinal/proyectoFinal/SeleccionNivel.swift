//
//  SeleccionNivel.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 27/11/24.
//

import Cocoa

class SeleccionNivel: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
    @IBOutlet var vcGame: ViewController!
    @objc dynamic var clientLog: [personaOBJ] = []
    
    var lvlOption: String?
    var name: String?
    var puntos: Int!
    var juegosJugados: Int!
     
    @IBAction func Nivel(_ sender: NSButton) {
        lvlOption = sender.title
        performSegue(withIdentifier: "irSegue", sender: self)
    }
     
    override func prepare(for segue: NSStoryboardSegue, sender:Any?) {
        if segue.identifier == "irSegue" {
            let destinoVC = segue.destinationController as! SeleccionarUsuario
            (segue.destinationController as! SeleccionarUsuario).clientLog = clientLog
            destinoVC.nivel = lvlOption
            destinoVC.name = name
            destinoVC.puntos = puntos
            destinoVC.juegosJugados = juegosJugados
        }
    }
}
