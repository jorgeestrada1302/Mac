class Pregunta {
    var texto: String
    var respuestaCorrecta: Bool
    var imagen: String?
    
    init(texto: String, respuestaCorrecta: Bool) {
        self.texto = texto
        self.respuestaCorrecta = respuestaCorrecta
    }
    
    func verificarRespuesta(respuesta: Bool) -> Bool {
        return respuesta == respuestaCorrecta
    }
}
