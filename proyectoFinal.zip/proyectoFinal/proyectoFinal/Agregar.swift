//
//  Agregar.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 27/11/24.
//

import Cocoa

class Agregar: NSViewController {
    
    @IBOutlet weak var nameLbl: NSTextField!
    @IBOutlet weak var age: NSTextField!
    @IBOutlet weak var mail: NSTextField!
    @IBOutlet var vc: ViewController!
    @IBOutlet weak var crearBtn: NSButton!
    @objc dynamic var clientLog: [personaOBJ] = []
    
    var flag:Bool = false
    var name:String?
    var posicion: Int!
    var puntos: Int = 0
    var juegosJugados:Int = 0
    var nuevoUsuario:Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if flag {
            nameLbl.stringValue = vc.clientLog[posicion].name
            puntos = vc.clientLog[posicion].puntos
            juegosJugados = vc.clientLog[posicion].juegosJugados
        }
        name = nameLbl.stringValue
    }
    
    @IBAction func agregarEvent(_ sender: Any) {
        
        guard let nameText = nameLbl?.stringValue, !nameText.isEmpty else {
            showAlert(message: "El nombre es obligatorio.")
            return
        }

        guard let ageText = age?.stringValue, let edad = Int(ageText), edad > 0 else {
            showAlert(message: "Por favor, ingresa una edad válida.")
            return
        }

        guard let mailText = mail?.stringValue, !mailText.isEmpty else {
            showAlert(message: "El correo electrónico es obligatorio.")
            return
        }
        
        vc.clientLog.append(personaOBJ(nameLbl.stringValue, age.stringValue, mail.stringValue, puntos, juegosJugados, nuevoUsuario))
        
        dismiss(self)
    }
    
    private func showAlert(message: String) {
        let alert = NSAlert()
        alert.messageText = "¡Error!"
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        if segue.identifier == "nivelSegue" {
            let destinoVC = segue.destinationController as! SeleccionNivel
            (segue.destinationController as! SeleccionNivel).clientLog = clientLog
            destinoVC.name = name
            destinoVC.puntos = puntos
            destinoVC.juegosJugados = juegosJugados
        }
    }
}
