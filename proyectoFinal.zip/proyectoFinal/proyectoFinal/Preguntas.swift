//
//  Preguntas.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 27/11/24.
//

import Cocoa

class Preguntas: NSViewController {
    
    var vidas = 1
    var vidasActuales = 1
    var nivel: String?
    var score = 0
    var scoreObjetivo = 0
    var name: String?
    var puntos: Int!
    var juegosJugados: Int!
    var scoreFinal = 0
    var preguntaSeleccionada: (enunciado: String, respuestaCorrecta: Bool) = ("", true)
    var status: String?
    var alert = NSAlert()
    
    @IBOutlet weak var vidasLbl: NSTextField!
    @IBOutlet weak var scoreLbl: NSTextField!
    @IBOutlet weak var preguntaLbl: NSTextField!
    @IBOutlet weak var reinicioBTN: NSButton!
    @IBOutlet weak var salirBTN: NSButton!
    @IBOutlet weak var verdaderoBTN: NSButton!
    @IBOutlet weak var falsoBTN: NSButton!
    @objc dynamic var clientLog: [personaOBJ] = []
    
    @IBAction func reinicioBtn(_ sender: NSButton) {
        score = 0
        scoreFinal = 0
        dificultad()
        alert = NSAlert()
        preguntasEasy = [
            ("La Gran Muralla China es visible desde la Luna.", false),
            ("El sol es una estrella de color blanco.", false),
            ("Las pirámides de Egipto fueron construidas por los\n esclavos.", false),
            ("La lengua más hablada en el mundo es el inglés.", false),
            ("El continente africano es el segundo más grande en\n términos de superficie.", true),
            ("Los delfines son mamíferos.", true),
            ("La Torre Eiffel fue construida como una estructura\n temporal para la Feria Mundial de París.", true),
            ("La Primera Guerra Mundial comenzó en 1912.", false),
            ("El océano Atlántico es más grande que el Pacífico.", false),
            ("El ser humano tiene más de 5 sentidos.", true)
        ]
        
        preguntasMedium = [
            ("La raíz cuadrada de 64 es 8.", true),
            ("El número pi (π) es un número racional.", false),
            ("La suma de los ángulos internos de un triángulo\n siempre es 180 grados.", true),
            ("El número 0 es un número impar.", false),
            ("Un cuadrado tiene 4 lados de igual longitud.", true),
            ("Un círculo tiene un área igual a πr².", true),
            ("La raíz cuadrada de un número negativo es un número\n real.", false),
            ("En un rectángulo, los ángulos internos son siempre de 90 grados.", true),
            ("La suma de los ángulos internos de un cuadrado es 360\n grados.", true),
            ("La multiplicación de dos números negativos da un\n resultado negativo.", false)
        ]
        
        preguntasHard = [
            ("El agua hierve a 100°C a nivel del mar.", true),
            ("Las plantas producen oxígeno durante el proceso de\n fotosíntesis.", true),
            ("La gravedad de la Tierra es más fuerte que la de la\n Luna.", true),
            ("El cuerpo humano tiene 206 huesos.", true),
            ("El sol es la estrella más cercana a la Tierra.", true),
            ("El oxígeno es el elemento más abundante en la\n atmósfera terrestre.", false),
            ("El corazón humano tiene cuatro cavidades.", true),
            ("La energía solar se produce mediante la fusión nuclear.", true),
            ("Las ballenas son peces.", false),
            ("Los humanos comparten el 99% de su ADN con los\n chimpancés.", true)
        ]
        cargarPreguntas()
        mostrarPregunta()
        verdaderoBTN.isEnabled = true
        falsoBTN.isEnabled = true
        reinicioBTN.isHidden = true
        salirBTN.isHidden = true
    }
    
    // Declaramos las preguntas para cada nivel
    var preguntasEasy: [(enunciado: String, respuestaCorrecta: Bool)] = [
        ("La Gran Muralla China es visible desde la Luna.", false),
        ("El sol es una estrella de color blanco.", false),
        ("Las pirámides de Egipto fueron construidas por los\n esclavos.", false),
        ("La lengua más hablada en el mundo es el inglés.", false),
        ("El continente africano es el segundo más grande en\n términos de superficie.", true),
        ("Los delfines son mamíferos.", true),
        ("La Torre Eiffel fue construida como una estructura\n temporal para la Feria Mundial de París.", true),
        ("La Primera Guerra Mundial comenzó en 1912.", false),
        ("El océano Atlántico es más grande que el Pacífico.", false),
        ("El ser humano tiene más de 5 sentidos.", true)
    ]
    
    var preguntasMedium: [(enunciado: String, respuestaCorrecta: Bool)] = [
        ("La raíz cuadrada de 64 es 8.", true),
        ("El número pi (π) es un número racional.", false),
        ("La suma de los ángulos internos de un triángulo\n siempre es 180 grados.", true),
        ("El número 0 es un número impar.", false),
        ("Un cuadrado tiene 4 lados de igual longitud.", true),
        ("Un círculo tiene un área igual a πr².", true),
        ("La raíz cuadrada de un número negativo es un número\n real.", false),
        ("En un rectángulo, los ángulos internos son siempre de 90 grados.", true),
        ("La suma de los ángulos internos de un cuadrado es 360\n grados.", true),
        ("La multiplicación de dos números negativos da un\n resultado negativo.", false)
    ]
    
    var preguntasHard: [(enunciado: String, respuestaCorrecta: Bool)] = [
        ("El agua hierve a 100°C a nivel del mar.", true),
        ("Las plantas producen oxígeno durante el proceso de\n fotosíntesis.", true),
        ("La gravedad de la Tierra es más fuerte que la de la\n Luna.", true),
        ("El cuerpo humano tiene 206 huesos.", true),
        ("El sol es la estrella más cercana a la Tierra.", true),
        ("El oxígeno es el elemento más abundante en la\n atmósfera terrestre.", false),
        ("El corazón humano tiene cuatro cavidades.", true),
        ("La energía solar se produce mediante la fusión nuclear.", true),
        ("Las ballenas son peces.", false),
        ("Los humanos comparten el 99% de su ADN con los\n chimpancés.", true)
    ]
    
    var preguntas: [(enunciado: String, respuestaCorrecta: Bool)] = []
    
    @IBAction func salirBtn(_ sender: NSButton) {
        self.dismiss(self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mostrarPregunta()
        dificultad()
        verdaderoBTN.isEnabled = true
        falsoBTN.isEnabled = true
        reinicioBTN.isHidden = true
        salirBTN.isHidden = true
    }
    
    private func cargarPreguntas() {
        // Cargar preguntas según el nivel
        if nivel == "Easy" {
            preguntas = preguntasEasy
        } else if nivel == "Medium" {
            preguntas = preguntasMedium
        } else if nivel == "Hard" {
            preguntas = preguntasHard
        }
    }
    
    private func mostrarPregunta() {
        var indice: Int
        var preguntasSeleccionadas: [(enunciado: String, respuestaCorrecta: Bool)]
    
        switch nivel {
        case "Easy":
            preguntasSeleccionadas = preguntasEasy
        case "Medium":
            preguntasSeleccionadas = preguntasMedium
        case "Hard":
            preguntasSeleccionadas = preguntasHard
        default:
            return
        }
        
        indice = Int.random(in: 0..<preguntasSeleccionadas.count)
        preguntaSeleccionada = preguntasSeleccionadas[indice]
        preguntaLbl.stringValue = preguntaSeleccionada.enunciado
        preguntasSeleccionadas.remove(at: indice)
        statusJuego()
    }
   
    private func dificultad() {
        if nivel == "Easy" {
            vidas = 3
            vidasActuales = 3
            scoreObjetivo = 5
            vidasLbl.stringValue = String(vidasActuales) + "/" + String(vidas)
            scoreLbl.stringValue = String(score) + "/" + String(scoreObjetivo)
        } else if nivel == "Medium" {
            vidas = 2
            vidasActuales = 2
            scoreObjetivo = 7
            vidasLbl.stringValue = String(vidasActuales) + "/" + String(vidas)
            scoreLbl.stringValue = String(score) + "/" + String(scoreObjetivo)
        } else if nivel == "Hard" {
            vidas = 1
            vidasActuales = 1
            scoreObjetivo = 10
            vidasLbl.stringValue = String(vidasActuales) + "/" + String(vidas)
            scoreLbl.stringValue = String(score) + "/" + String(scoreObjetivo)
        }
    }
    
    @IBAction func verdaderoBtn(_ sender: NSButton) {
        if preguntaSeleccionada.respuestaCorrecta == true {
            score += 1
            scoreLbl.stringValue = String(score) + "/" + String(scoreObjetivo)
        } else {
            vidasActuales -= 1
            vidasLbl.stringValue = String(vidasActuales) + "/" + String(vidas)
        }
        mostrarPregunta()
    }
    
    @IBAction func falsoBtn(_ sender: NSButton) {
        if preguntaSeleccionada.respuestaCorrecta == false {
            score += 1
            scoreLbl.stringValue = String(score) + "/" + String(scoreObjetivo)
        } else {
            vidasActuales -= 1
            vidasLbl.stringValue = String(vidasActuales) + "/" + String(vidas)
        }
        mostrarPregunta()
    }
    
    private func statusJuego() {
        if score == scoreObjetivo {
            status = "Ganador"
            reinicioBTN.isHidden = false
            salirBTN.isHidden = false
            showAlert()
        } else if vidasActuales == 0 {
            status = "Perdedor"
            reinicioBTN.isHidden = false
            salirBTN.isHidden = false
            showAlert()
        }
        scoreFinal = score + puntos
        puntos = scoreFinal
        juegosJugados += 1
    }
    
    func showAlert() {
        if status == "Ganador" {
            alert.messageText = "¡Haz Ganado!"
            alert.informativeText = "Lograste contestar las preguntas correctamente."
            alert.icon = NSImage(named:NSImage.Name("ganador"))
            alert.runModal()
        } else {
            alert.messageText = "¡Haz Perdido!"
            alert.informativeText = "No lograste contestar las preguntas correctamente, intentalo de nuevo."
            alert.icon = NSImage(named:NSImage.Name("perdedor"))
            alert.runModal()
        }
        verdaderoBTN.isEnabled = false
        falsoBTN.isEnabled = false
    }
    override func prepare(for segue: NSStoryboardSegue, sender:Any?) {
        if segue.identifier == "scoreSegue" {
            let destinoVC = segue.destinationController as! SeleccionarUsuario
            (segue.destinationController as! Tabla).clientLog = clientLog
            destinoVC.name = name
            destinoVC.puntos = puntos
            destinoVC.juegosJugados = juegosJugados
        }
    }
}
