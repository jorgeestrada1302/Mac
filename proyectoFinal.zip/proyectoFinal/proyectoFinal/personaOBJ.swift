//
//  personaOBJ.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 26/11/24.
//

import Cocoa

class personaOBJ: NSObject {
    
    @objc dynamic var name: String
    @objc dynamic var age: String
    @objc dynamic var mail: String
    @objc dynamic var puntos: Int
    @objc dynamic var juegosJugados: Int
    @objc dynamic var nuevoUsuario: Bool
    
    init(_ name: String, _ age: String, _ mail: String, _ puntos: Int, _ juegosJugados: Int, _ nuevoUsuario: Bool) {
        self.name = name
        self.age = age
        self.mail = mail
        self.puntos = puntos
        self.juegosJugados = juegosJugados
        self.nuevoUsuario = nuevoUsuario
    }
}
