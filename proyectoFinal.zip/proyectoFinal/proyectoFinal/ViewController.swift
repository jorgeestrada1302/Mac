//
//  ViewController.swift
//  proyectoFinal
//
//  Created by ISSC_401_AD_2024 on 26/11/24.
//

import Cocoa

class ViewController: NSViewController {
    @objc dynamic var clientLog: [personaOBJ] = [personaOBJ("Carlos", "20" , "correo@ejemplo.com", 0, 0, true)]
    
    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
        if (segue.identifier == "showSegue") {
            (segue.destinationController as! Tabla).clientLog = clientLog
            (segue.destinationController as! Tabla).vcTabla = self
        } else if (segue.identifier == "addSegue") {
            (segue.destinationController as! Agregar).vc = self
            (segue.destinationController as! Agregar).clientLog = clientLog
        } else if (segue.identifier == "gameSegue") {
            (segue.destinationController as! SeleccionNivel).vcGame = self
            (segue.destinationController as! SeleccionNivel).clientLog = clientLog
        }
    }
}
