import Cocoa

class Tabla: NSViewController {
    
    @IBOutlet var vcTabla: ViewController!
    @IBOutlet weak var scrollView: NSScrollView!
    @IBOutlet weak var salirBtn: NSButton!
    @objc dynamic var clientLog: [personaOBJ] = []
    
    @IBAction func salir(_ sender: NSButton) {
        self.dismiss(self)
    }
    override func viewDidAppear() {
        super.viewDidAppear()
        
       
        // Asegúrate de que los usuarios nuevos tengan score y juegosJugados en 0
        for persona in clientLog {
            if persona.nuevoUsuario {
                persona.puntos = 0
                persona.juegosJugados = 0
            }
        }
    }
}
